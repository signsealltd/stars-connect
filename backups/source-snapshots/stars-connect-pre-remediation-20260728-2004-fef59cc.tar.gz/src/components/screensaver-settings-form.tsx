﻿/* eslint-disable @next/next/no-img-element */
"use client";

import { useEffect, useState } from "react";
import { Monitor, Save } from "lucide-react";
import { screensaverDefaults, type ScreensaverSettings } from "@/lib/screensaver";

export function ScreensaverSettingsForm() {
  const [settings, setSettings] = useState<ScreensaverSettings>(screensaverDefaults);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  useEffect(() => { fetch("/api/settings/screensaver", { cache: "no-store" }).then(async response => { const body = await response.json(); if (!response.ok) throw new Error(body.error); setSettings(body); }).catch(error => setMessage(error.message)).finally(() => setLoading(false)); }, []);
  async function save(event: React.FormEvent) { event.preventDefault(); setMessage(""); const response = await fetch("/api/settings/screensaver", { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify(settings) }); const body = await response.json(); setMessage(response.ok ? "Screensaver settings saved. Devices will cache them when next online." : body.error || "Unable to save settings."); }
  if (loading) return <div className="empty">Loading screensaver settingsâ€¦</div>;
  const check = (key: keyof ScreensaverSettings, label: string) => <label className="check-row"><input type="checkbox" checked={Boolean(settings[key])} onChange={event => setSettings({ ...settings, [key]: event.target.checked })}/><span>{label}</span></label>;
  return <form autoComplete="off" className="grid" onSubmit={save}>
    {message && <div className={message.includes("saved") ? "alert alert-success" : "alert alert-error"}>{message}</div>}
    <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fit,minmax(310px,1fr))" }}>
      <section className="card" style={{ padding: 22 }}><h2><Monitor size={20}/> Content</h2>
        {check("screensaverEnabled", "Enable idle screensaver")}
        <label className="form-label">Idle timeout (seconds)<input className="field" type="number" min="15" max="3600" value={settings.idleTimeoutSeconds} onChange={event => setSettings({ ...settings, idleTimeoutSeconds: Number(event.target.value) })}/></label>
        <label className="form-label">Heading<input className="field" maxLength={120} value={settings.headline} onChange={event => setSettings({ ...settings, headline: event.target.value })}/></label>
        <label className="form-label">Touch/wake message<input className="field" maxLength={120} value={settings.screensaverMessage} onChange={event => setSettings({ ...settings, screensaverMessage: event.target.value })}/></label>
        <label className="form-label">Device/location name<input className="field" maxLength={120} placeholder="Uses provisioned device name when blank" value={settings.deviceLocationName} onChange={event => setSettings({ ...settings, deviceLocationName: event.target.value })}/></label>
        {check("showClock", "Show time")}{check("showDate", "Show date")}{check("showDeviceName", "Show device/location")}{check("showOnSiteCount", "Show number of people currently on site")}
      </section>
      <section className="card" style={{ padding: 22 }}><h2>Logo and colours</h2>
        {check("showLogo", "Show logo")}
        <label className="form-label">Logo URL or data image<input className="field" value={settings.logoUrl} onChange={event => setSettings({ ...settings, logoUrl: event.target.value })}/><small className="muted">Use a local path such as /branding/stars-logo.svg, an HTTPS image URL, or paste a compressed data image.</small></label>
        <label className="form-label">Background colour<input className="field" type="color" value={settings.backgroundColor} onChange={event => setSettings({ ...settings, backgroundColor: event.target.value })}/></label>
        <label className="form-label">Text colour<input className="field" type="color" value={settings.textColor} onChange={event => setSettings({ ...settings, textColor: event.target.value })}/></label>
        <label className="form-label">Accent/star colour<input className="field" type="color" value={settings.accentColor} onChange={event => setSettings({ ...settings, accentColor: event.target.value })}/></label>
        <div className="card" style={{ minHeight: 170, padding: 20, textAlign: "center", background: settings.backgroundColor, color: settings.textColor }}>{settings.showLogo && settings.logoUrl && <img src={settings.logoUrl} alt="" style={{ maxWidth: 110, maxHeight: 70 }}/>}<h3>{settings.headline}</h3><p>{settings.screensaverMessage}</p></div>
      </section>
      <section className="card" style={{ padding: 22 }}><h2>Background animation</h2>
        {check("constellationEnabled", "Enable constellation background")}
        <label className="form-label">Animation intensity: {settings.constellationIntensity}%<input type="range" min="0" max="100" value={settings.constellationIntensity} onChange={event => setSettings({ ...settings, constellationIntensity: Number(event.target.value) })}/></label>
        <p className="muted">Animation becomes static when reduced motion is enabled and is reduced at night.</p>
      </section>
      <section className="card" style={{ padding: 22 }}><h2>Day and night dimming</h2><div className="form-grid">
        <label className="form-label">Day starts<input className="field" type="time" value={settings.dayModeStart} onChange={event => setSettings({ ...settings, dayModeStart: event.target.value })}/></label>
        <label className="form-label">Day brightness %<input className="field" type="number" min="5" max="100" value={settings.dayDimLevel} onChange={event => setSettings({ ...settings, dayDimLevel: Number(event.target.value) })}/></label>
        <label className="form-label">Evening starts<input className="field" type="time" value={settings.eveningModeStart} onChange={event => setSettings({ ...settings, eveningModeStart: event.target.value })}/></label>
        <label className="form-label">Evening brightness %<input className="field" type="number" min="5" max="100" value={settings.eveningDimLevel} onChange={event => setSettings({ ...settings, eveningDimLevel: Number(event.target.value) })}/></label>
        <label className="form-label">Night starts<input className="field" type="time" value={settings.nightModeStart} onChange={event => setSettings({ ...settings, nightModeStart: event.target.value })}/></label>
        <label className="form-label">Night brightness %<input className="field" type="number" min="5" max="100" value={settings.nightDimLevel} onChange={event => setSettings({ ...settings, nightDimLevel: Number(event.target.value) })}/></label>
      </div></section>
    </div>
    <button className="btn primary"><Save size={17}/>Save screensaver settings</button>
  </form>;
}

